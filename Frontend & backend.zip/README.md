
  # Frontend Improvements

  This is a code bundle for Frontend Improvements. The original project is available at https://www.figma.com/design/jJ4O94vae9wyw8jPIinqGT/Frontend-Improvements.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  