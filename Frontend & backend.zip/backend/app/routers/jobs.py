import uuid

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from ..database import get_db
from ..deps import get_current_user, require_admin
from ..models import Job, User
from ..schemas import JobIn, JobOut


router = APIRouter(prefix="/jobs", tags=["jobs"])


@router.get("", response_model=list[JobOut])
def list_jobs(
    type: str | None = None,
    company: str | None = None,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user),
) -> list[Job]:
    qry = db.query(Job).filter(Job.status == "live")
    if type:
        qry = qry.filter(Job.type == type)
    if company:
        qry = qry.filter(Job.company.ilike(f"%{company}%"))
    return qry.order_by(Job.posted.desc()).all()


@router.post("", response_model=JobOut, status_code=201)
def create_job(
    body: JobIn,
    db: Session = Depends(get_db),
    current: User = Depends(get_current_user),
) -> Job:
    if current.role not in ("alumni", "admin"):
        raise HTTPException(403, "Only alumni or admin can post jobs")
    j = Job(
        id=f"jb_{uuid.uuid4().hex[:10]}",
        company=body.company,
        role=body.role,
        location=body.location,
        type=body.type,
        salary=body.salary,
        tags=body.tags,
        posted="just now",
        posted_by_id=current.id,
        alumni_count=0,
        status="pending",
    )
    db.add(j)
    db.commit()
    db.refresh(j)
    return j


@router.post("/{job_id}/approve", response_model=JobOut)
def approve_job(job_id: str, db: Session = Depends(get_db), _: User = Depends(require_admin)) -> Job:
    j = db.get(Job, job_id)
    if not j:
        raise HTTPException(404, "Job not found")
    j.status = "live"
    db.commit()
    db.refresh(j)
    return j


@router.post("/{job_id}/flag", response_model=JobOut)
def flag_job(job_id: str, db: Session = Depends(get_db), _: User = Depends(require_admin)) -> Job:
    j = db.get(Job, job_id)
    if not j:
        raise HTTPException(404, "Job not found")
    j.status = "flagged"
    db.commit()
    db.refresh(j)
    return j
