from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from ..database import get_db
from ..deps import get_current_user
from ..models import Story, User
from ..schemas import StoryOut


router = APIRouter(prefix="/stories", tags=["stories"])


@router.get("", response_model=list[StoryOut])
def list_stories(
    tag: str | None = None,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user),
) -> list[Story]:
    qry = db.query(Story)
    if tag:
        qry = qry.filter(Story.tag == tag)
    return qry.all()


@router.get("/{story_id}", response_model=StoryOut)
def get_story(story_id: str, db: Session = Depends(get_db), _: User = Depends(get_current_user)) -> Story:
    s = db.get(Story, story_id)
    if not s:
        raise HTTPException(404, "Story not found")
    return s
