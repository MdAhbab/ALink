from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from ..database import get_db
from ..deps import get_current_user, require_admin
from ..models import User, Verification
from ..schemas import VerificationOut


router = APIRouter(prefix="/verifications", tags=["verifications"])


@router.get("", response_model=list[VerificationOut])
def list_queue(db: Session = Depends(get_db), _: User = Depends(require_admin)) -> list[Verification]:
    return (
        db.query(Verification)
        .filter(Verification.status == "pending")
        .order_by(Verification.submitted_at.asc())
        .all()
    )


@router.post("/{vid}/approve", response_model=VerificationOut)
def approve(vid: str, db: Session = Depends(get_db), _: User = Depends(require_admin)) -> Verification:
    v = db.get(Verification, vid)
    if not v:
        raise HTTPException(404, "Not found")
    v.status = "approved"
    user = db.get(User, v.user_id)
    if user:
        user.verified = True
    db.commit()
    db.refresh(v)
    return v


@router.post("/{vid}/reject", response_model=VerificationOut)
def reject(vid: str, db: Session = Depends(get_db), _: User = Depends(require_admin)) -> Verification:
    v = db.get(Verification, vid)
    if not v:
        raise HTTPException(404, "Not found")
    v.status = "rejected"
    db.commit()
    db.refresh(v)
    return v


@router.post("/request", status_code=201)
def request_verification(
    db: Session = Depends(get_db),
    current: User = Depends(get_current_user),
) -> dict:
    import uuid
    from datetime import date
    v = Verification(
        id=f"vr_{uuid.uuid4().hex[:10]}",
        user_id=current.id,
        name=current.name,
        university=current.university,
        role=current.role,
        submitted_at=date.today().isoformat(),
        status="pending",
    )
    db.add(v)
    db.commit()
    return {"ok": True, "id": v.id}
