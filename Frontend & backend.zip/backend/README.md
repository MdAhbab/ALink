# ALink — FastAPI Backend

A drop-in REST API for the ALink frontend. Built with **FastAPI + SQLAlchemy 2 + SQLite**, mirroring every domain shape declared in `src/app/lib/mock.ts` and consumed across the React components.

```
backend/
├── alink.db                ← SQLite database (auto-created on first run)
├── requirements.txt
├── run.sh                  ← convenience script
├── .env.example
└── app/
    ├── main.py             ← FastAPI app + CORS + lifespan + router mounting
    ├── config.py           ← env-driven settings
    ├── database.py         ← engine, Session, Base, get_db
    ├── deps.py             ← current-user dependency
    ├── security.py         ← bcrypt + JWT helpers
    ├── models.py           ← all SQLAlchemy ORM models
    ├── schemas.py          ← all Pydantic request/response models
    ├── seed.py             ← imports mock.ts data into the DB
    └── routers/
        ├── auth.py
        ├── users.py
        ├── connections.py
        ├── bookings.py
        ├── referrals.py
        ├── events.py
        ├── jobs.py
        ├── stories.py
        ├── mentorship.py
        ├── achievements.py
        ├── notifications.py
        ├── activity.py
        ├── chat.py
        ├── verifications.py
        ├── settings.py
        └── admin.py
```

## Quick start

```bash
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
python -m app.seed          # creates tables + seeds mock data
uvicorn app.main:app --reload --port 8000
```

Then point the frontend at `http://localhost:8000` (set `VITE_API_URL` in the frontend `.env`).

## Endpoint map (mirrors every frontend page)

| Frontend page              | Endpoint group                       |
| -------------------------- | ------------------------------------ |
| `/login`, `/register`      | `POST /auth/login`, `/auth/register` |
| `/onboarding`              | `PATCH /users/me`                    |
| `/app` (Dashboard)         | `GET /users/me`, `/activity`, `/notifications` |
| `/app/profile`             | `GET/PATCH /users/me`, `POST /users/me/avatar` |
| `/app/connections`         | `/connections`, `/connections/requests` |
| `/app/finder`              | `GET /users?q=&role=&...`            |
| `/app/calendar`, `/bookings` | `/bookings` (CRUD)                 |
| `/app/referrals`           | `/referrals` (CRUD)                  |
| `/app/inbox`               | `/chat/threads`, `/chat/messages`    |
| `/app/jobs`                | `/jobs`                              |
| `/app/events`              | `/events`                            |
| `/app/mentorship`          | `/mentorship/programs`               |
| `/app/stories`             | `/stories`                           |
| `/app/achievements`        | `/achievements`                      |
| `/app/settings`            | `/settings/prefs`                    |
| `/admin/*`                 | `/admin/...`, `/verifications`       |

All endpoints return JSON shaped to match the existing TypeScript types in
`src/app/lib/mock.ts` so the frontend can swap mock imports for fetch calls
without touching component code.

## Auth model

Bearer JWT (HS256). Returned by `/auth/login` and `/auth/register`. The
frontend should store it (e.g. in `localStorage` under `alink:token`) and send
it as `Authorization: Bearer <token>` on every request. `get_current_user`
parses & validates it.
