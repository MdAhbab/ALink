import * as React from "react";
import { motion } from "motion/react";
import { events } from "../lib/mock";
import { Badge } from "../components/ui/badge";
import { Button } from "../components/ui/button";
import { Card, CardContent } from "../components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "../components/ui/tabs";
import { Calendar, MapPin, Users, Sparkles } from "lucide-react";
import { toast } from "sonner";

const kindLabel: Record<string, string> = {
  panel: "Panel", mixer: "Mixer", workshop: "Workshop", career_fair: "Career Fair",
};

export default function Events() {
  const [filter, setFilter] = React.useState<string>("all");
  const filtered = events.filter(e => filter === "all" || e.kind === filter);

  return (
    <div className="space-y-6">
      <div className="rounded-3xl border border-border bg-card p-6 md:p-8 relative overflow-hidden">
        <div aria-hidden className="absolute -top-16 -right-10 size-60 rounded-full brand-gradient opacity-20 blur-3xl" />
        <Badge variant="secondary" className="rounded-full"><Sparkles className="size-3" /> What's on this week</Badge>
        <h1 className="font-serif text-4xl md:text-5xl mt-3">Events &amp; meetups</h1>
        <p className="text-muted-foreground">Panels, mixers, workshops, and career fairs — IRL and online.</p>
      </div>

      <Tabs value={filter} onValueChange={setFilter}>
        <TabsList>
          <TabsTrigger value="all">All</TabsTrigger>
          <TabsTrigger value="panel">Panels</TabsTrigger>
          <TabsTrigger value="mixer">Mixers</TabsTrigger>
          <TabsTrigger value="workshop">Workshops</TabsTrigger>
          <TabsTrigger value="career_fair">Career fairs</TabsTrigger>
        </TabsList>

        <TabsContent value={filter}>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filtered.map((e, i) => (
              <motion.div key={e.id}
                initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }}
                whileHover={{ y: -3 }}>
                <Card className="overflow-hidden h-full">
                  <div className="h-28 relative grid place-items-center text-white font-serif text-3xl" style={{ background: `linear-gradient(135deg, ${e.cover}, ${e.cover}55)` }}>
                    <div className="absolute inset-0 bg-[radial-gradient(60%_50%_at_30%_30%,rgba(255,255,255,0.35),transparent)]" />
                    {new Date(e.date).toLocaleDateString(undefined, { month: "short", day: "numeric" })}
                  </div>
                  <CardContent className="p-5">
                    <Badge variant="outline" className="rounded-full">{kindLabel[e.kind]}</Badge>
                    <div className="font-serif text-xl mt-2">{e.title}</div>
                    <div className="text-xs text-muted-foreground mt-2 space-y-1">
                      <div className="inline-flex items-center gap-1.5"><Calendar className="size-3.5" /> {e.date} · {e.time}</div>
                      <div className="inline-flex items-center gap-1.5"><MapPin className="size-3.5" /> {e.location}</div>
                      <div className="inline-flex items-center gap-1.5"><Users className="size-3.5" /> {e.attending} / {e.capacity}</div>
                    </div>
                    <div className="mt-3 h-1.5 w-full rounded-full bg-muted overflow-hidden">
                      <motion.div className="h-full brand-gradient" initial={{ width: 0 }} animate={{ width: `${(e.attending/e.capacity)*100}%` }} transition={{ duration: 0.8, delay: 0.2 + i*0.04 }} />
                    </div>
                    <div className="mt-4 flex items-center justify-between">
                      <div className="text-xs text-muted-foreground">Hosted by {e.host}</div>
                      <Button size="sm" onClick={() => toast.success(`You're going to ${e.title}`)}>RSVP</Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
