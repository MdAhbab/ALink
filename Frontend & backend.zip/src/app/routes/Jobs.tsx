import * as React from "react";
import { motion, AnimatePresence } from "motion/react";
import { jobs } from "../lib/mock";
import { Avatar, AvatarFallback, AvatarImage } from "../components/ui/avatar";
import { Badge } from "../components/ui/badge";
import { Button } from "../components/ui/button";
import { Card, CardContent } from "../components/ui/card";
import { Input } from "../components/ui/input";
import { Briefcase, Building2, MapPin, Search, Sparkles, Heart } from "lucide-react";
import { toast } from "sonner";

export default function Jobs() {
  const [q, setQ] = React.useState("");
  const [saved, setSaved] = React.useState<Set<string>>(new Set());
  const filtered = jobs.filter(j =>
    [j.role, j.company, j.location, ...j.tags].join(" ").toLowerCase().includes(q.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="rounded-3xl border border-border bg-card p-6 md:p-8 relative overflow-hidden">
        <div aria-hidden className="absolute -bottom-16 -right-10 size-60 rounded-full opacity-20 blur-3xl" style={{ background: "var(--mint)" }} />
        <Badge variant="secondary" className="rounded-full"><Sparkles className="size-3" /> Alumni-vouched roles</Badge>
        <h1 className="font-serif text-4xl md:text-5xl mt-3">Job board</h1>
        <p className="text-muted-foreground">Roles posted by alumni who can refer you — not random listings.</p>
        <div className="mt-5 relative max-w-md">
          <Search className="size-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input className="pl-9 h-11" placeholder="Search role, company, tag…" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
      </div>

      <AnimatePresence>
        <motion.div layout className="grid lg:grid-cols-2 gap-4">
          {filtered.map((j, i) => {
            const isSaved = saved.has(j.id);
            return (
              <motion.div layout key={j.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }}>
                <Card className="hover:-translate-y-0.5 transition">
                  <CardContent className="p-5 flex gap-4">
                    <div className="size-14 rounded-2xl grid place-items-center text-white shrink-0" style={{ background: `linear-gradient(135deg, var(--brand-500), var(--amber))` }}>
                      <span className="font-mono text-sm">{j.company.slice(0,2).toUpperCase()}</span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <div className="font-serif text-xl">{j.role}</div>
                          <div className="text-sm text-muted-foreground flex items-center gap-3 mt-0.5">
                            <span className="inline-flex items-center gap-1"><Building2 className="size-3.5" /> {j.company}</span>
                            <span className="inline-flex items-center gap-1"><MapPin className="size-3.5" /> {j.location}</span>
                          </div>
                        </div>
                        <Badge variant="outline" className="rounded-full">{j.type}</Badge>
                      </div>
                      <div className="mt-2 flex flex-wrap gap-1.5">
                        {j.tags.map(t => <Badge key={t} variant="secondary" className="rounded-full text-[10px]">{t}</Badge>)}
                      </div>
                      <div className="mt-3 flex items-center gap-3 text-xs text-muted-foreground">
                        <span>{j.salary}</span>·<span>{j.posted}</span>
                      </div>
                      <div className="mt-3 flex items-center justify-between">
                        <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                          <Avatar className="size-5"><AvatarImage src={j.postedBy.avatar} /><AvatarFallback>{j.postedBy.name[0]}</AvatarFallback></Avatar>
                          Posted by {j.postedBy.name}
                          <Badge variant="secondary" className="rounded-full text-[10px]">{j.alumniCount} alumni here</Badge>
                        </div>
                        <div className="flex gap-2">
                          <Button size="sm" variant="ghost" onClick={() => {
                            setSaved(s => { const n = new Set(s); n.has(j.id) ? n.delete(j.id) : n.add(j.id); return n; });
                          }}>
                            <Heart className={`size-4 ${isSaved ? "fill-[var(--rose)] text-[var(--rose)]" : ""}`} />
                          </Button>
                          <Button size="sm" onClick={() => toast.success(`Referral started for ${j.role}`)}><Briefcase className="size-3.5" /> Request referral</Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
