import * as React from "react";
import { me as defaultMe, type Person, type Role } from "./mock";

type AuthState = {
  user: Person | null;
  setRole: (r: Role) => void;
  login: (role?: Role) => void;
  logout: () => void;
  update: (p: Partial<Person>) => void;
};

const Ctx = React.createContext<AuthState | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = React.useState<Person | null>(() => {
    try {
      const raw = localStorage.getItem("alink:user");
      return raw ? (JSON.parse(raw) as Person) : null;
    } catch { return null; }
  });

  React.useEffect(() => {
    if (user) localStorage.setItem("alink:user", JSON.stringify(user));
    else localStorage.removeItem("alink:user");
  }, [user]);

  const value: AuthState = {
    user,
    setRole: (r) => setUser((u) => (u ? { ...u, role: r } : { ...defaultMe, role: r })),
    login: (role = "student") => setUser({ ...defaultMe, role }),
    logout: () => setUser(null),
    update: (p) => setUser((u) => (u ? { ...u, ...p } : u)),
  };
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useAuth() {
  const v = React.useContext(Ctx);
  if (!v) throw new Error("useAuth must be used inside AuthProvider");
  return v;
}
