import { motion } from "motion/react";

export function Logo({ size = 28, withMark = true, withWord = true, className = "" }: { size?: number; withMark?: boolean; withWord?: boolean; className?: string }) {
  return (
    <div className={`inline-flex items-center gap-2 ${className}`}>
      {withMark && (
        <motion.svg
          width={size} height={size} viewBox="0 0 32 32" fill="none"
          initial={{ rotate: -8, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }}
          transition={{ type: "spring", stiffness: 180, damping: 18 }}
        >
          <defs>
            <linearGradient id="alinkG" x1="0" y1="0" x2="32" y2="32" gradientUnits="userSpaceOnUse">
              <stop offset="0" stopColor="#7C5CFF" />
              <stop offset=".55" stopColor="#B19BFF" />
              <stop offset="1" stopColor="#F5B461" />
            </linearGradient>
          </defs>
          <rect x="1" y="1" width="30" height="30" rx="9" fill="url(#alinkG)" />
          <path d="M10 22 L16 9 L22 22" stroke="white" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M12.5 17.5 H19.5" stroke="white" strokeWidth="2.4" strokeLinecap="round" />
        </motion.svg>
      )}
      {withWord && (
        <span className="font-serif text-[1.35em] leading-none tracking-tight">
          A<span className="brand-gradient-text">link</span>
        </span>
      )}
    </div>
  );
}
